#ifndef MTSB_H
#define MTSB_H

extern void init();
extern char *get();
extern void put(char *s);
extern void fini();

#endif
